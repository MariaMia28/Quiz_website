

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Test yourself</title>
  <link rel="stylesheet" href="style_user.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
  

</head>
<body>

<p class="title_user">Hello!</p>


  <div class="container_quiz">
  <div class="container_q1">
    <div class="text_q1">Start quiz#1</div>
    <button class="quiz1"><a style="text-decoration:none" href="quiz1.html" >Quiz#1</a></button>
  </div>
  <div class="container_q2">
    <div class="text_q2">Start quiz#2</div>	
    <button class="quiz2"><a style="text-decoration:none" href="quiz2.html" >Quiz#2</a></button>
  </div>
  <div class="container_q3">
    <div class="text_q3">Start quiz#3</div>
    <button class="quiz3"><a style="text-decoration:none" href="quiz3.html" >Quiz#3</a></button>
  </div>
</div>


    <div class="container_logout">
      <p><a style="text-decoration:none" href="logout.php">Log out</a></p>
    

  </div>
</body>
</html>
